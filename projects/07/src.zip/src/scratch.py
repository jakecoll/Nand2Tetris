notP = True

noPointer = notP ? 1:0

print(noPointer)
